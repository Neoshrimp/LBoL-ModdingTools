Adds `MODDED` text to top-right run info.

---
*Change log*

`1.1.1` Actually fix text position.

`1.1.0` Fix text position.